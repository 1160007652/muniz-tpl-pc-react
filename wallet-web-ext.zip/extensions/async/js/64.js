(this["webpackJsonp"] = this["webpackJsonp"] || []).push([[64],{

/***/ "./src/lib/web_pkg/package.json":
/*!**************************************!*\
  !*** ./src/lib/web_pkg/package.json ***!
  \**************************************/
/*! exports provided: name, collaborators, version, files, module, types, sideEffects, default */
/***/ (function(module) {

eval("module.exports = JSON.parse(\"{\\\"name\\\":\\\"wasm\\\",\\\"collaborators\\\":[\\\"ngolub <ngolub@stanford.edu>\\\"],\\\"version\\\":\\\"0.1.0\\\",\\\"files\\\":[\\\"wasm_bg.wasm\\\",\\\"wasm.js\\\",\\\"wasm.d.ts\\\"],\\\"module\\\":\\\"wasm.js\\\",\\\"types\\\":\\\"wasm.d.ts\\\",\\\"sideEffects\\\":\\\"false\\\"}\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuL3NyYy9saWIvd2ViX3BrZy9wYWNrYWdlLmpzb24uanMiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/lib/web_pkg/package.json\n");

/***/ })

}]);