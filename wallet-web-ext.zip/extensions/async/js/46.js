(this["webpackJsonp"] = this["webpackJsonp"] || []).push([[46],{

/***/ "./src/lib/web_pkg/wasm_bg.d.ts":
/*!**************************************!*\
  !*** ./src/lib/web_pkg/wasm_bg.d.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("throw new Error(\"Module parse failed: Unexpected token (3:19)\\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\\n| /* tslint:disable */\\n| /* eslint-disable */\\n> export const memory: WebAssembly.Memory;\\n| export function random_asset_type(a: number): void;\\n| export function verify_authenticated_txn(a: number, b: number, c: number, d: number): number;\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIuL3NyYy9saWIvd2ViX3BrZy93YXNtX2JnLmQudHMuanMiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/lib/web_pkg/wasm_bg.d.ts\n");

/***/ })

}]);