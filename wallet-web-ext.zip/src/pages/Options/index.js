import React from 'react';
import ReactDOM from 'react-dom';

import '_src/less/index.less';
import './index.less';

ReactDOM.render(
  <div>
    Options 页面 配置项文件 1234
    <input placeholder="请输入Findora 访问密码"></input>
  </div>,
  document.getElementById('root'),
);
