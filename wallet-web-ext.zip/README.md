# findora-extsions-wallet

## 框架配置

react、react-router、mobx、webpack、less

## 运行方式

1、开发环境

> yarn dev

2、生产环境

> yarn build

---

## Framework configuration

react、react-router、mobx、webpack、less

## Operation mode

1、development env

> yarn dev ,

2、production environment

> yarn build

## 改版

1、重新改版 创建钱包、管理钱包的方式
