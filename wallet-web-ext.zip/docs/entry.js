
    window.reactComponents = {};

    window.vueComponents = {};

  
      import React from "react";

      import ReactDOM from "react-dom";


      import ReactWrapper from '../node_modules/better-docs/lib/react-wrapper.js';

      window.React = React;

      window.ReactDOM = ReactDOM;

      window.ReactWrapper = ReactWrapper;

    
    import './styles/reset.css';

    import './styles/iframe.css';

  import Component0 from '../src/components/FindoraBoxView/index.js';
reactComponents['FindoraBoxView'] = Component0;

import Component1 from '../src/components/FindoraButton/index.js';
reactComponents['FindoraButton'] = Component1;

import Component2 from '../src/components/FindoraHeader/index.js';
reactComponents['FindoraHeader'] = Component2;

import Component3 from '../src/components/FindoraRouterBack/index.js';
reactComponents['FindoraRouterBack'] = Component3;

import Component4 from '../src/components/FindoraWebContainer/index.js';
reactComponents['FindoraWebContainer'] = Component4;

import Component5 from '../src/components/TransactionsItem/index.js';
reactComponents['TransactionsItem'] = Component5;

import Component6 from '../src/components/WalletListItem/index.js';
reactComponents['WalletListItem'] = Component6;

import Component7 from '../src/components/WalletName/index.js';
reactComponents['WalletName'] = Component7;